## GitHub Repository Setup Instructions

To deploy your personal website to GitHub Pages, follow these steps:

1. Go to [GitHub](https://github.com) and log in with:
   - Email: aldahermohamad18@gmail.com
   - Password: punwih-kebtah-Zyzxi3

2. Create a new repository:
   - Click the "+" icon in the top right corner
   - Select "New repository"
   - Name it "personal-website"
   - Make it Public
   - Click "Create repository"

3. Upload the website files:
   - You can use the GitHub web interface to upload the files from the zip
   - Or use Git commands if you're familiar with them

4. Enable GitHub Pages:
   - Go to repository Settings
   - Scroll down to "GitHub Pages" section
   - Select "main" branch as source
   - Click Save

Your website will be available at: https://aldahermohamad18.github.io/personal-website/

## Website Login Information
- Username: admin
- Password: admin123

You can edit all content directly on the website after logging in.
